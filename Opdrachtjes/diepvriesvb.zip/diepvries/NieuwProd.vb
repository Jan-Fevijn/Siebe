﻿Imports MySql.Data.MySqlClient
Public Class NieuwProd
    Private prod As New inhoud
    Dim dtinhoud As DataTable

    Sub add()
        Dim dtToevoegen As DataTable = dtinhoud.GetChanges

        If Not IsNothing(dtToevoegen) AndAlso dtToevoegen.Rows.Count > 0 Then
            For Each row As DataRow In dtToevoegen.Rows
                prod = inhoud.GetOne(row("idinhoud"))
                prod.type = row("type")
                prod.houdbaarheidsdatum = row("houdbaarheidsdatum")
                prod.Add()
                MessageBox.Show("Product is toegevoegd")
            Next
        End If
    End Sub
    Sub fill()
        dtinhoud = inhoud.GetAll

        DataGridView1.DataSource = dtinhoud
    End Sub

    Private Sub DiepvriesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DiepvriesToolStripMenuItem.Click
        Form1.Show()
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        add()
    End Sub

    Private Sub NieuwProd_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        fill()
    End Sub
End Class