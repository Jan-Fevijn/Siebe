﻿Imports MySql.Data.MySqlClient
Imports System.Data.Sql
Imports System
Imports System.Data
Imports System.Data.OleDb
Public Class Gerechten
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click

    End Sub


    Private Sub loadProducten()
        producten.ShowItemToolTips = True
        producten.View = View.Details

        producten.Clear()

        producten.Columns.Add("gerechtID", 120)
        producten.Columns.Add("naam", 120)
        Dim connStr As String = "server=localhost;user=root;database=project2;port=3307;password=usbw;"
        Dim conn As New MySqlConnection(connStr)

        conn.Open()

        Dim mySelectQuery As String = "select * from gerecht "
        Dim myCommand As New MySqlCommand(mySelectQuery, conn)

        Dim rd As MySqlDataReader
        rd = myCommand.ExecuteReader()
        Dim user As New user
        While (rd.Read())
            Dim product As New adminGerecht(rd(0), rd(1), rd(2), rd(3), rd(4))
            ADMIN.adminGerechten.Add(product)
        End While

        For Each product In ADMIN.adminGerechten
            Dim TempStr(3) As String
            Dim TempNode As ListViewItem
            TempStr(0) = product.idGerecht
            TempStr(1) = product.naam
            TempStr(2) = product.img
            Dim vegan

            If product.vegan = True Then
                vegan = "veganistisch gerecht"
            ElseIf product.veganistisch = True Then
                vegan = "vegitarisch gerecht"
            Else
                vegan = "niet vegitarisch / veganistisch "
            End If

            TempStr(3) = product.vegan


            TempNode = New ListViewItem(TempStr)
            producten.Items.Add(TempNode)
        Next
    End Sub



    Private Sub ProductenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ProductenToolStripMenuItem.Click
        Product.Show()
        Me.Hide()
    End Sub

    Private Sub EvenementenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EvenementenToolStripMenuItem.Click
        Evenmenten.Show()
        Me.Hide()
    End Sub
End Class