﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Evenmenten
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.EvenementenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ProductenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GerechtenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.txtEvenement = New System.Windows.Forms.TextBox()
        Me.txtPersonen = New System.Windows.Forms.TextBox()
        Me.txtDagen = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.dgvEvenement = New System.Windows.Forms.DataGridView()
        Me.cbGerechten = New System.Windows.Forms.ComboBox()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.dgvEvenement, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.EvenementenToolStripMenuItem, Me.ProductenToolStripMenuItem, Me.GerechtenToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(800, 28)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'EvenementenToolStripMenuItem
        '
        Me.EvenementenToolStripMenuItem.Name = "EvenementenToolStripMenuItem"
        Me.EvenementenToolStripMenuItem.Size = New System.Drawing.Size(112, 24)
        Me.EvenementenToolStripMenuItem.Text = "Evenementen"
        '
        'ProductenToolStripMenuItem
        '
        Me.ProductenToolStripMenuItem.Name = "ProductenToolStripMenuItem"
        Me.ProductenToolStripMenuItem.Size = New System.Drawing.Size(90, 24)
        Me.ProductenToolStripMenuItem.Text = "Producten"
        '
        'GerechtenToolStripMenuItem
        '
        Me.GerechtenToolStripMenuItem.Name = "GerechtenToolStripMenuItem"
        Me.GerechtenToolStripMenuItem.Size = New System.Drawing.Size(90, 24)
        Me.GerechtenToolStripMenuItem.Text = "Gerechten"
        '
        'txtEvenement
        '
        Me.txtEvenement.Location = New System.Drawing.Point(351, 80)
        Me.txtEvenement.Name = "txtEvenement"
        Me.txtEvenement.Size = New System.Drawing.Size(152, 22)
        Me.txtEvenement.TabIndex = 2
        '
        'txtPersonen
        '
        Me.txtPersonen.Location = New System.Drawing.Point(351, 124)
        Me.txtPersonen.Name = "txtPersonen"
        Me.txtPersonen.Size = New System.Drawing.Size(152, 22)
        Me.txtPersonen.TabIndex = 3
        '
        'txtDagen
        '
        Me.txtDagen.Location = New System.Drawing.Point(351, 166)
        Me.txtDagen.Name = "txtDagen"
        Me.txtDagen.Size = New System.Drawing.Size(152, 22)
        Me.txtDagen.TabIndex = 4
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(221, 83)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(124, 17)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Naam Evenement:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(276, 124)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(73, 17)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Personen:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(291, 169)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(54, 17)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Dagen:"
        '
        'dgvEvenement
        '
        Me.dgvEvenement.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvEvenement.Location = New System.Drawing.Point(173, 259)
        Me.dgvEvenement.Name = "dgvEvenement"
        Me.dgvEvenement.RowHeadersWidth = 51
        Me.dgvEvenement.RowTemplate.Height = 24
        Me.dgvEvenement.Size = New System.Drawing.Size(457, 150)
        Me.dgvEvenement.TabIndex = 1
        '
        'cbGerechten
        '
        Me.cbGerechten.FormattingEnabled = True
        Me.cbGerechten.Location = New System.Drawing.Point(351, 214)
        Me.cbGerechten.Name = "cbGerechten"
        Me.cbGerechten.Size = New System.Drawing.Size(121, 24)
        Me.cbGerechten.TabIndex = 8
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(630, 141)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(75, 23)
        Me.btnAdd.TabIndex = 9
        Me.btnAdd.Text = "Add"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'Evenmenten
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.btnAdd)
        Me.Controls.Add(Me.cbGerechten)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtDagen)
        Me.Controls.Add(Me.txtPersonen)
        Me.Controls.Add(Me.txtEvenement)
        Me.Controls.Add(Me.dgvEvenement)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Evenmenten"
        Me.Text = "Evenmenten"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.dgvEvenement, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents EvenementenToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ProductenToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents GerechtenToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents txtEvenement As TextBox
    Friend WithEvents txtPersonen As TextBox
    Friend WithEvents txtDagen As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents dgvEvenement As DataGridView
    Friend WithEvents cbGerechten As ComboBox
    Friend WithEvents btnAdd As Button
End Class
