﻿Public Class Evenmenten
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click

    End Sub



    Private Sub ProductenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ProductenToolStripMenuItem.Click
        Product.Show()
        Me.Hide()
    End Sub

    Private Sub GerechtenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles GerechtenToolStripMenuItem.Click
        Gerechten.Show()
        Me.Hide()
    End Sub
End Class