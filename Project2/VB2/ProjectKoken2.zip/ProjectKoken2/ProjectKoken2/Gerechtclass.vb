﻿Public Class Gerechtclass
    Private _id As String
    Private _naam As String
    Private _hoeveelheid As String
    Private _eenheid As String
    Public Property Id() As String
        Get
            Return _id
        End Get
        Set(ByVal value As String)
            _id = value
        End Set
    End Property

    Public Property Naam() As String
        Get
            Return _naam
        End Get
        Set(ByVal value As String)
            _naam = value
        End Set
    End Property

    Public Property Hoeveelheid() As String
        Get
            Return _hoeveelheid
        End Get
        Set(ByVal value As String)
            _hoeveelheid = value
        End Set
    End Property

    Public Property Eenheid() As String
        Get
            Return _eenheid
        End Get
        Set(ByVal value As String)
            _eenheid = value
        End Set
    End Property
End Class
