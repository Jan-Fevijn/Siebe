﻿Public Class Evenementclass

    Private _id As String
    Private _naam As String
    Private _personen As String
    Private _dagen As String
    Public Property Id() As String
        Get
            Return _id
        End Get
        Set(ByVal value As String)
            _id = value
        End Set
    End Property

    Public Property Naam() As String
        Get
            Return _naam
        End Get
        Set(ByVal value As String)
            _naam = value
        End Set
    End Property

    Public Property Personen() As String
        Get
            Return _personen
        End Get
        Set(ByVal value As String)
            _personen = value
        End Set
    End Property

    Public Property Dagen() As String
        Get
            Return _dagen
        End Get
        Set(ByVal value As String)
            _dagen = value
        End Set
    End Property
End Class
