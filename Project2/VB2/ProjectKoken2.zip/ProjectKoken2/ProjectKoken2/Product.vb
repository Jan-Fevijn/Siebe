﻿Public Class Product
    Private Sub GerechtenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles GerechtenToolStripMenuItem.Click
        Gerechten.Show()
        Me.Hide()
    End Sub

    Private Sub EvenementenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EvenementenToolStripMenuItem.Click
        Evenmenten.Show()
        Me.Hide()
    End Sub
End Class
